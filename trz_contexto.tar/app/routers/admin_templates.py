from pathlib import Path

from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..db import get_db
from ..deps import require_roles
from ..models import (
    User,
    MessageTemplate,
    FollowupKind,
    MessageTemplateChannel,
)

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parents[1]
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

ALLOWED = ["ADMINISTRADOR", "ADMINISTRATIVO"]


@router.get("/admin/templates", response_class=HTMLResponse)
def templates_list(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    rows = db.scalars(
        select(MessageTemplate).order_by(MessageTemplate.name.asc())
    ).all()

    return templates.TemplateResponse(
        "templates_list.html",
        {
            "request": request,
            "me": me,
            "rows": rows,
        },
    )


@router.get("/admin/templates/new", response_class=HTMLResponse)
def template_new_page(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    return templates.TemplateResponse(
        "template_form.html",
        {
            "request": request,
            "me": me,
            "row": None,
            "kinds": [k.value for k in FollowupKind],
            "channels": [c.value for c in MessageTemplateChannel],
        },
    )


@router.post("/admin/templates/new")
def template_new_do(
    name: str = Form(...),
    kind: str = Form(...),
    channel: str = Form(...),
    subject: str = Form(""),
    body: str = Form(""),
    is_active: str = Form("1"),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    row = MessageTemplate(
        name=(name or "").strip(),
        kind=FollowupKind(kind),
        channel=MessageTemplateChannel(channel),
        subject=(subject or "").strip(),
        body=(body or "").strip(),
        is_active=(is_active == "1"),
    )
    db.add(row)
    db.commit()
    return RedirectResponse("/admin/templates", status_code=302)


@router.get("/admin/templates/{template_id}/edit", response_class=HTMLResponse)
def template_edit_page(
    request: Request,
    template_id: int,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    row = db.get(MessageTemplate, template_id)
    if not row:
        return RedirectResponse("/admin/templates", status_code=302)

    return templates.TemplateResponse(
        "template_form.html",
        {
            "request": request,
            "me": me,
            "row": row,
            "kinds": [k.value for k in FollowupKind],
            "channels": [c.value for c in MessageTemplateChannel],
        },
    )


@router.post("/admin/templates/{template_id}/edit")
def template_edit_do(
    template_id: int,
    name: str = Form(...),
    kind: str = Form(...),
    channel: str = Form(...),
    subject: str = Form(""),
    body: str = Form(""),
    is_active: str = Form("1"),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    row = db.get(MessageTemplate, template_id)
    if not row:
        return RedirectResponse("/admin/templates", status_code=302)

    row.name = (name or "").strip()
    row.kind = FollowupKind(kind)
    row.channel = MessageTemplateChannel(channel)
    row.subject = (subject or "").strip()
    row.body = (body or "").strip()
    row.is_active = (is_active == "1")

    db.commit()
    return RedirectResponse("/admin/templates", status_code=302)