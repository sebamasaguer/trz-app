from pathlib import Path
from datetime import date, datetime, timedelta
from urllib.parse import quote

from fastapi import APIRouter, Request, Depends, Form, Query
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import select, or_

from ..db import get_db
from ..deps import require_roles
from ..models import (
    User,
    StudentFollowup,
    FollowupKind,
    FollowupStatus,
    FollowupPriority,
    FollowupChannel,
    FollowupAction,
    FollowupActionType,
    MessageTemplate,
    MessageTemplateChannel,
)

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parents[1]
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

ALLOWED = ["ADMINISTRADOR", "ADMINISTRATIVO"]


def normalize_phone_ar(phone: str | None) -> str:
    raw = "".join(ch for ch in (phone or "") if ch.isdigit())
    if not raw:
        return ""
    if raw.startswith("54"):
        return raw
    if raw.startswith("0"):
        raw = raw[1:]
    return f"54{raw}"


def infer_priority(kind: str, status: str, next_contact_date: date | None) -> FollowupPriority:
    today = date.today()

    if status in ["REACTIVADO", "DESCARTADO"]:
        return FollowupPriority.BAJA

    if next_contact_date:
        if next_contact_date < today:
            return FollowupPriority.CRITICA
        if next_contact_date == today:
            return FollowupPriority.ALTA
        if next_contact_date <= today + timedelta(days=7):
            return FollowupPriority.MEDIA

    if kind == "MOROSIDAD":
        return FollowupPriority.ALTA
    if kind == "INACTIVIDAD":
        return FollowupPriority.MEDIA

    return FollowupPriority.MEDIA


def status_group_title(status_value: str) -> str:
    mapping = {
        "PENDIENTE": "Pendiente",
        "CONTACTADO": "Contactado",
        "RESPONDIO": "Respondió",
        "REACTIVADO": "Reactivado",
        "DESCARTADO": "Descartado",
    }
    return mapping.get(status_value, status_value)


def render_template_text(template_body: str, student: User, row: StudentFollowup | None = None) -> str:
    nombre = (student.full_name or student.first_name or student.email or "Hola").strip()
    data = {
        "{nombre}": nombre,
        "{email}": student.email or "",
        "{telefono}": student.phone or "",
        "{titulo}": (row.title if row else "") or "",
        "{resultado}": (row.result_summary if row else "") or "",
        "{proximo_contacto}": row.next_contact_date.strftime("%d/%m/%Y") if row and row.next_contact_date else "",
    }

    text = template_body or ""
    for k, v in data.items():
        text = text.replace(k, v)
    return text


def find_best_template(db: Session, kind_value: str, channel_value: str) -> MessageTemplate | None:
    rows = db.scalars(
        select(MessageTemplate)
        .where(
            MessageTemplate.kind == FollowupKind(kind_value),
            MessageTemplate.channel.in_([
                MessageTemplateChannel(channel_value),
                MessageTemplateChannel.GENERAL,
            ]),
            MessageTemplate.is_active == True,
        )
        .order_by(MessageTemplate.channel.asc(), MessageTemplate.id.asc())
    ).all()

    if rows:
        exact = [r for r in rows if r.channel.value == channel_value]
        return exact[0] if exact else rows[0]
    return None


def build_followup_message(db: Session, student: User, row: StudentFollowup | None = None, kind_value: str | None = None, channel_value: str | None = None) -> tuple[str, str]:
    kind = kind_value or (row.kind.value if row else "GENERAL")
    channel = channel_value or (row.channel.value if row else "WHATSAPP")

    tpl = find_best_template(db, kind, channel)
    if tpl:
        subject = tpl.subject or f"Seguimiento TRZ Funcional - {kind}"
        body = render_template_text(tpl.body, student, row=row)
        return subject, body

    nombre = (student.full_name or student.first_name or student.email or "Hola").strip()

    if kind == "MOROSIDAD":
        body = f"Hola {nombre}, ¿cómo estás? Te escribimos desde TRZ Funcional porque vimos una cuota pendiente y queremos ayudarte a regularizarla. Quedamos atentos."
    elif kind == "INACTIVIDAD":
        body = f"Hola {nombre}, ¿cómo estás? Te escribimos desde TRZ Funcional porque notamos que hace un tiempo no venís y queríamos saber si querés retomar. Quedamos atentos."
    else:
        body = f"Hola {nombre}, ¿cómo estás? Te escribimos desde TRZ Funcional."

    return f"Seguimiento TRZ Funcional - {kind}", body


def whatsapp_url(student: User, message: str) -> str:
    phone = normalize_phone_ar(student.phone)
    encoded = quote(message)
    if phone:
        return f"https://wa.me/{phone}?text={encoded}"
    return f"https://web.whatsapp.com/send?text={encoded}"


def email_url(student: User, subject: str, body: str) -> str:
    to = quote(student.email or "")
    sub = quote(subject or "Seguimiento TRZ Funcional")
    bod = quote(body or "")
    return f"mailto:{to}?subject={sub}&body={bod}"


def save_action(
    db: Session,
    row: StudentFollowup,
    me: User,
    action_type: FollowupActionType,
    channel: FollowupChannel | None,
    summary: str,
    payload_text: str = "",
    external_ref: str = "",
):
    action = FollowupAction(
        followup_id=row.id,
        created_by_id=me.id,
        action_type=action_type,
        channel=channel,
        summary=(summary or "").strip(),
        payload_text=(payload_text or "").strip(),
        external_ref=(external_ref or "").strip(),
    )
    db.add(action)

    row.last_action_at = datetime.utcnow()
    row.last_action_type = action_type.value

    if action_type in [FollowupActionType.MENSAJE_ENVIADO, FollowupActionType.WHATSAPP_ENVIADO, FollowupActionType.EMAIL_ENVIADO]:
        row.last_message_sent_at = datetime.utcnow()

    db.commit()


def serialize_followup_for_actions(db: Session, row: StudentFollowup) -> dict:
    student = row.student
    if not student:
        return {}

    subject, message = build_followup_message(db, student, row=row)

    return {
        "subject": subject,
        "message": message,
        "whatsapp_url": whatsapp_url(student, message),
        "email_url": email_url(student, subject, message),
        "phone_normalized": normalize_phone_ar(student.phone),
    }


@router.get("/admin/followups", response_class=HTMLResponse)
def followups_list(
    request: Request,
    q: str = "",
    kind: str = "",
    status: str = "",
    priority: str = "",
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    stmt = (
        select(StudentFollowup)
        .options(
            joinedload(StudentFollowup.student),
            joinedload(StudentFollowup.created_by),
        )
        .order_by(StudentFollowup.created_at.desc(), StudentFollowup.id.desc())
    )

    if q.strip():
        like = f"%{q.strip()}%"
        stmt = stmt.join(User, StudentFollowup.student_id == User.id).where(
            or_(
                User.full_name.ilike(like),
                User.first_name.ilike(like),
                User.last_name.ilike(like),
                User.email.ilike(like),
                User.dni.ilike(like),
                StudentFollowup.title.ilike(like),
                StudentFollowup.notes.ilike(like),
                StudentFollowup.result_summary.ilike(like),
            )
        )

    if kind.strip():
        stmt = stmt.where(StudentFollowup.kind == FollowupKind(kind))

    if status.strip():
        stmt = stmt.where(StudentFollowup.status == FollowupStatus(status))

    if priority.strip():
        stmt = stmt.where(StudentFollowup.priority == FollowupPriority(priority))

    rows = db.scalars(stmt).all()

    row_actions = {}
    for row in rows:
        row_actions[row.id] = serialize_followup_for_actions(db, row)

    return templates.TemplateResponse(
        "followups_list.html",
        {
            "request": request,
            "me": me,
            "rows": rows,
            "row_actions": row_actions,
            "q": q,
            "kind": kind,
            "status": status,
            "priority": priority,
            "kinds": [k.value for k in FollowupKind],
            "statuses": [s.value for s in FollowupStatus],
            "priorities": [p.value for p in FollowupPriority],
        },
    )


@router.get("/admin/followups/new", response_class=HTMLResponse)
def followup_new_page(
    request: Request,
    student_id: int = Query(...),
    kind: str = Query("GENERAL"),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    student = db.get(User, student_id)
    if not student:
        return RedirectResponse("/admin/users", status_code=302)

    subject, suggested_message = build_followup_message(db, student, row=None, kind_value=kind, channel_value="WHATSAPP")

    return templates.TemplateResponse(
        "followup_form.html",
        {
            "request": request,
            "me": me,
            "student": student,
            "kind_default": kind,
            "statuses": [s.value for s in FollowupStatus],
            "kinds": [k.value for k in FollowupKind],
            "channels": [c.value for c in FollowupChannel],
            "suggested_message": suggested_message,
            "suggested_whatsapp_url": whatsapp_url(student, suggested_message),
            "suggested_email_url": email_url(student, subject, suggested_message),
            "error": "",
        },
    )


@router.post("/admin/followups/new")
def followup_new_do(
    student_id: int = Form(...),
    kind: str = Form(...),
    status: str = Form(...),
    channel: str = Form("WHATSAPP"),
    title: str = Form(""),
    notes: str = Form(""),
    next_contact_date: str = Form(""),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    student = db.get(User, student_id)
    if not student:
        return RedirectResponse("/admin/users", status_code=302)

    kind_enum = FollowupKind(kind)
    status_enum = FollowupStatus(status)
    channel_enum = FollowupChannel(channel)

    next_date = None
    if next_contact_date.strip():
        try:
            next_date = date.fromisoformat(next_contact_date.strip())
        except Exception:
            next_date = None

    priority_enum = infer_priority(kind, status, next_date)

    row = StudentFollowup(
        student_id=student.id,
        created_by_id=me.id,
        kind=kind_enum,
        status=status_enum,
        priority=priority_enum,
        channel=channel_enum,
        title=(title or "").strip(),
        notes=(notes or "").strip(),
        next_contact_date=next_date,
        automation_enabled=True,
    )
    db.add(row)
    db.commit()

    save_action(
        db=db,
        row=row,
        me=me,
        action_type=FollowupActionType.NOTA,
        channel=channel_enum,
        summary="Seguimiento creado",
        payload_text=row.notes,
    )

    return RedirectResponse("/admin/followups", status_code=302)


@router.get("/admin/followups/{followup_id}/edit", response_class=HTMLResponse)
def followup_edit_page(
    request: Request,
    followup_id: int,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    row = db.get(StudentFollowup, followup_id)
    if not row:
        return RedirectResponse("/admin/followups", status_code=302)

    student = db.get(User, row.student_id)
    subject, suggested_message = build_followup_message(db, student, row=row, channel_value=row.channel.value)

    return templates.TemplateResponse(
        "followup_edit.html",
        {
            "request": request,
            "me": me,
            "row": row,
            "student": student,
            "statuses": [s.value for s in FollowupStatus],
            "kinds": [k.value for k in FollowupKind],
            "priorities": [p.value for p in FollowupPriority],
            "channels": [c.value for c in FollowupChannel],
            "suggested_message": suggested_message,
            "suggested_whatsapp_url": whatsapp_url(student, suggested_message),
            "suggested_email_url": email_url(student, subject, suggested_message),
        },
    )


@router.post("/admin/followups/{followup_id}/edit")
def followup_edit_do(
    followup_id: int,
    kind: str = Form(...),
    status: str = Form(...),
    priority: str = Form(""),
    channel: str = Form("WHATSAPP"),
    title: str = Form(""),
    notes: str = Form(""),
    next_contact_date: str = Form(""),
    result_summary: str = Form(""),
    automation_enabled: str = Form("1"),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    row = db.get(StudentFollowup, followup_id)
    if not row:
        return RedirectResponse("/admin/followups", status_code=302)

    prev_status = row.status.value

    row.kind = FollowupKind(kind)
    row.status = FollowupStatus(status)
    row.channel = FollowupChannel(channel)
    row.title = (title or "").strip()
    row.notes = (notes or "").strip()
    row.result_summary = (result_summary or "").strip()
    row.automation_enabled = (automation_enabled == "1")

    if next_contact_date.strip():
        try:
            row.next_contact_date = date.fromisoformat(next_contact_date.strip())
        except Exception:
            row.next_contact_date = None
    else:
        row.next_contact_date = None

    if priority.strip():
        row.priority = FollowupPriority(priority)
    else:
        row.priority = infer_priority(kind, status, row.next_contact_date)

    if row.status == FollowupStatus.CONTACTADO and row.contacted_at is None:
        row.contacted_at = datetime.utcnow()

    if row.status in [FollowupStatus.REACTIVADO, FollowupStatus.DESCARTADO]:
        if row.resolved_at is None:
            row.resolved_at = datetime.utcnow()
    else:
        row.resolved_at = None

    db.commit()

    if prev_status != row.status.value:
        save_action(
            db=db,
            row=row,
            me=me,
            action_type=FollowupActionType.CAMBIO_ESTADO,
            channel=row.channel,
            summary=f"Estado cambiado de {prev_status} a {row.status.value}",
            payload_text=row.result_summary,
        )

    return RedirectResponse("/admin/followups", status_code=302)


@router.post("/admin/followups/{followup_id}/mark-whatsapp")
def mark_whatsapp_sent(
    followup_id: int,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    row = db.get(StudentFollowup, followup_id)
    if not row:
        return RedirectResponse("/admin/followups", status_code=302)

    row.status = FollowupStatus.CONTACTADO
    if row.contacted_at is None:
        row.contacted_at = datetime.utcnow()

    student = db.get(User, row.student_id)
    _, msg = build_followup_message(db, student, row=row, channel_value="WHATSAPP")

    db.commit()

    save_action(
        db=db,
        row=row,
        me=me,
        action_type=FollowupActionType.WHATSAPP_ENVIADO,
        channel=FollowupChannel.WHATSAPP,
        summary="WhatsApp marcado como enviado",
        payload_text=msg,
    )

    return RedirectResponse("/admin/followups", status_code=302)


@router.post("/admin/followups/{followup_id}/mark-email")
def mark_email_sent(
    followup_id: int,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    row = db.get(StudentFollowup, followup_id)
    if not row:
        return RedirectResponse("/admin/followups", status_code=302)

    row.status = FollowupStatus.CONTACTADO
    if row.contacted_at is None:
        row.contacted_at = datetime.utcnow()

    student = db.get(User, row.student_id)
    subject, msg = build_followup_message(db, student, row=row, channel_value="EMAIL")

    db.commit()

    save_action(
        db=db,
        row=row,
        me=me,
        action_type=FollowupActionType.EMAIL_ENVIADO,
        channel=FollowupChannel.EMAIL,
        summary=f"Email marcado como enviado: {subject}",
        payload_text=msg,
    )

    return RedirectResponse("/admin/followups", status_code=302)


@router.get("/admin/followups/reminders", response_class=HTMLResponse)
def reminders_page(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    today = date.today()

    rows = db.scalars(
        select(StudentFollowup)
        .options(joinedload(StudentFollowup.student))
        .where(
            StudentFollowup.automation_enabled == True,
            StudentFollowup.next_contact_date.is_not(None),
            StudentFollowup.status.in_([
                FollowupStatus.PENDIENTE,
                FollowupStatus.CONTACTADO,
                FollowupStatus.RESPONDIO,
            ]),
        )
        .order_by(StudentFollowup.next_contact_date.asc(), StudentFollowup.id.desc())
    ).all()

    return templates.TemplateResponse(
        "followup_reminders.html",
        {
            "request": request,
            "me": me,
            "today": today,
            "rows": rows,
        },
    )


@router.post("/admin/followups/{followup_id}/mark-reminder")
def mark_reminder_sent(
    followup_id: int,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    row = db.get(StudentFollowup, followup_id)
    if not row:
        return RedirectResponse("/admin/followups/reminders", status_code=302)

    row.reminder_sent_at = datetime.utcnow()
    db.commit()

    save_action(
        db=db,
        row=row,
        me=me,
        action_type=FollowupActionType.RECORDATORIO,
        channel=row.channel,
        summary="Recordatorio marcado como enviado",
    )

    return RedirectResponse("/admin/followups/reminders", status_code=302)

@router.get("/admin/followups/kanban", response_class=HTMLResponse)
def followups_kanban(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    rows = db.scalars(
        select(StudentFollowup)
        .options(
            joinedload(StudentFollowup.student),
            joinedload(StudentFollowup.created_by),
        )
        .order_by(StudentFollowup.id.desc())
    ).all()

    columns = {s.value: [] for s in FollowupStatus}
    for row in rows:
        columns[row.status.value].append(row)

    row_actions = {}
    for row in rows:
        row_actions[row.id] = serialize_followup_for_actions(db, row)

    return templates.TemplateResponse(
        "followups_kanban.html",
        {
            "request": request,
            "me": me,
            "columns": columns,
            "row_actions": row_actions,
            "status_titles": {s.value: status_group_title(s.value) for s in FollowupStatus},
            "today": date.today(),
        },
    )

