from pathlib import Path
from datetime import datetime, date, time as dtime

from fastapi import APIRouter, Request, Depends, Form, Path as FPath
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import select, func

from ..db import get_db
from ..deps import require_roles
from ..models import (
    User, Role,
    Membership, MembershipPrice, MembershipAssignment,
    MembershipKind, PaymentMethod,
    MembershipUsage, ServiceKind,
)
from ..security import qr_make_payload

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parents[1]
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

ALLOWED = ["ADMINISTRADOR", "ADMINISTRATIVO"]


def _price_map(prices: list[MembershipPrice]) -> dict[str, float]:
    m = {}
    for p in prices:
        m[p.payment_method.value] = float(p.amount)
    return m


def _parse_amount(s: str) -> float | None:
    s = (s or "").strip().replace(",", ".")
    if not s:
        return None
    return float(s)


# =========================
# LISTADO / CRUD MEMBRESÍAS
# =========================

@router.get("/admin/memberships", response_class=HTMLResponse)
def memberships_list(
    request: Request,
    q: str = "",
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    stmt = select(Membership).order_by(Membership.id.desc())
    if q.strip():
        like = f"%{q.strip()}%"
        stmt = stmt.where(Membership.name.ilike(like))
    items = db.scalars(stmt).all()

    prices = db.scalars(select(MembershipPrice).order_by(MembershipPrice.id.asc())).all()
    prices_by_mid: dict[int, dict[str, float]] = {}
    for p in prices:
        prices_by_mid.setdefault(p.membership_id, {})
        prices_by_mid[p.membership_id][p.payment_method.value] = float(p.amount)

    return templates.TemplateResponse(
        "admin_memberships.html",
        {"request": request, "me": me, "items": items, "q": q, "prices_by_mid": prices_by_mid},
    )


@router.get("/admin/memberships/new", response_class=HTMLResponse)
def membership_new_page(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    return templates.TemplateResponse(
        "membership_form.html",
        {
            "request": request,
            "me": me,
            "item": None,
            "error": None,
            "kinds": [k.value for k in MembershipKind],
        },
    )


@router.post("/admin/memberships/new")
def membership_new(
    name: str = Form(...),
    kind: str = Form(...),

    funcional_classes: int = Form(0),
    musculacion_classes: int = Form(0),
    funcional_unlimited: str = Form(""),
    musculacion_unlimited: str = Form(""),

    price_lista: str = Form(""),
    price_efectivo: str = Form(""),
    price_transferencia: str = Form(""),

    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    k = MembershipKind(kind)
    fu = (funcional_unlimited or "").lower() in ("on", "true", "1", "yes")
    mu = (musculacion_unlimited or "").lower() in ("on", "true", "1", "yes")

    fc = None
    mc = None

    if k == MembershipKind.FUNCIONAL:
        fc = None if fu else (funcional_classes if funcional_classes > 0 else None)
        mc = None
        mu = False
    elif k == MembershipKind.MUSCULACION:
        mc = None if mu else (musculacion_classes if musculacion_classes > 0 else None)
        fc = None
        fu = False
    elif k == MembershipKind.COMBINACION:
        fu = False
        mu = False
        fc = funcional_classes if funcional_classes > 0 else None
        mc = musculacion_classes if musculacion_classes > 0 else None
    else:  # CLASE_SUELTA
        fu = False
        mu = False
        fc = None
        mc = None

    m = Membership(
        name=name.strip(),
        kind=k,
        funcional_classes=fc,
        musculacion_classes=mc,
        funcional_unlimited=fu,
        musculacion_unlimited=mu,
        is_active=True,
    )
    db.add(m)
    db.commit()

    pl = _parse_amount(price_lista)
    pe = _parse_amount(price_efectivo)
    pt = _parse_amount(price_transferencia)

    if pl is not None:
        db.add(MembershipPrice(membership_id=m.id, payment_method=PaymentMethod.LISTA, amount=pl))
    if pe is not None:
        db.add(MembershipPrice(membership_id=m.id, payment_method=PaymentMethod.EFECTIVO, amount=pe))
    if pt is not None:
        db.add(MembershipPrice(membership_id=m.id, payment_method=PaymentMethod.TRANSFERENCIA, amount=pt))
    db.commit()

    return RedirectResponse(url="/admin/memberships", status_code=302)


@router.get("/admin/memberships/{mid}/edit", response_class=HTMLResponse)
def membership_edit_page(
    request: Request,
    mid: int = FPath(...),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    item = db.get(Membership, mid)
    if not item:
        return RedirectResponse(url="/admin/memberships", status_code=302)

    prices = db.scalars(select(MembershipPrice).where(MembershipPrice.membership_id == item.id)).all()
    pmap = _price_map(prices)

    return templates.TemplateResponse(
        "membership_form.html",
        {
            "request": request,
            "me": me,
            "item": item,
            "error": None,
            "kinds": [k.value for k in MembershipKind],
            "pmap": pmap,
        },
    )


@router.post("/admin/memberships/{mid}/edit")
def membership_edit(
    mid: int,
    name: str = Form(...),
    kind: str = Form(...),

    funcional_classes: int = Form(0),
    musculacion_classes: int = Form(0),
    funcional_unlimited: str = Form(""),
    musculacion_unlimited: str = Form(""),

    price_lista: str = Form(""),
    price_efectivo: str = Form(""),
    price_transferencia: str = Form(""),

    is_active: str = Form("true"),

    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    item = db.get(Membership, mid)
    if not item:
        return RedirectResponse(url="/admin/memberships", status_code=302)

    k = MembershipKind(kind)
    fu = (funcional_unlimited or "").lower() in ("on", "true", "1", "yes")
    mu = (musculacion_unlimited or "").lower() in ("on", "true", "1", "yes")

    fc = None
    mc = None

    if k == MembershipKind.FUNCIONAL:
        fc = None if fu else (funcional_classes if funcional_classes > 0 else None)
        mc = None
        mu = False
    elif k == MembershipKind.MUSCULACION:
        mc = None if mu else (musculacion_classes if musculacion_classes > 0 else None)
        fc = None
        fu = False
    elif k == MembershipKind.COMBINACION:
        fu = False
        mu = False
        fc = funcional_classes if funcional_classes > 0 else None
        mc = musculacion_classes if musculacion_classes > 0 else None
    else:
        fu = False
        mu = False
        fc = None
        mc = None

    item.name = name.strip()
    item.kind = k
    item.funcional_classes = fc
    item.musculacion_classes = mc
    item.funcional_unlimited = fu
    item.musculacion_unlimited = mu
    item.is_active = (is_active or "").lower() in ("true", "1", "on", "yes")

    pl = _parse_amount(price_lista)
    pe = _parse_amount(price_efectivo)
    pt = _parse_amount(price_transferencia)

    def upsert(method: PaymentMethod, val: float | None):
        row = db.scalars(
            select(MembershipPrice).where(
                MembershipPrice.membership_id == item.id,
                MembershipPrice.payment_method == method
            )
        ).first()
        if val is None:
            if row:
                db.delete(row)
            return
        if row:
            row.amount = val
        else:
            db.add(MembershipPrice(membership_id=item.id, payment_method=method, amount=val))

    upsert(PaymentMethod.LISTA, pl)
    upsert(PaymentMethod.EFECTIVO, pe)
    upsert(PaymentMethod.TRANSFERENCIA, pt)

    db.commit()
    return RedirectResponse(url="/admin/memberships", status_code=302)


# =========================
# ASIGNAR MEMBRESÍA (MENSUAL)
# =========================

@router.get("/admin/memberships/assign", response_class=HTMLResponse)
def membership_assign_page(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    memberships = db.scalars(select(Membership).where(Membership.is_active == True).order_by(Membership.name.asc())).all()
    students = db.scalars(select(User).where(User.role == Role.ALUMNO, User.is_active == True).order_by(User.last_name.asc())).all()

    return templates.TemplateResponse(
        "membership_assign.html",
        {"request": request, "me": me, "memberships": memberships, "students": students, "ok": None, "error": None},
    )


@router.post("/admin/memberships/assign")
def membership_assign_do(
    student_id: int = Form(...),
    membership_id: int = Form(...),
    start_date: str = Form(""),
    payment_method: str = Form(""),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    student = db.get(User, student_id)
    m = db.get(Membership, membership_id)
    if (not student) or (student.role != Role.ALUMNO) or (not m) or (not m.is_active):
        return RedirectResponse(url="/admin/memberships/assign", status_code=302)

    sd = None
    if start_date.strip():
        sd = datetime.strptime(start_date.strip(), "%Y-%m-%d").date()

    base_date = sd or date.today()
    period = base_date.strftime("%Y-%m")

    db.query(MembershipAssignment).filter(
        MembershipAssignment.student_id == student.id,
        MembershipAssignment.is_active == True,
        MembershipAssignment.period_yyyymm == period,
    ).update({"is_active": False})

    pm = None
    snap = None
    if payment_method.strip():
        pm = PaymentMethod(payment_method)
        price = db.scalars(
            select(MembershipPrice).where(
                MembershipPrice.membership_id == m.id,
                MembershipPrice.payment_method == pm
            )
        ).first()
        if price:
            snap = float(price.amount)

    a = MembershipAssignment(
        membership_id=m.id,
        student_id=student.id,
        assigned_by=me.id,
        start_date=sd,
        is_active=True,
        period_yyyymm=period,
        payment_method=pm,
        amount_snapshot=snap,
    )
    db.add(a)
    db.commit()

    return RedirectResponse(url="/admin/memberships/assign", status_code=302)


# =========================
# CONSUMO DE CUPOS (ASISTENCIA)
# reglas: no domingo, no duplicado día/servicio,
# solo mes actual, horario 07:00-22:00, cupo.
# =========================

@router.get("/admin/memberships/consume", response_class=HTMLResponse)
def consume_page(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    students = db.scalars(
        select(User).where(User.role == Role.ALUMNO, User.is_active == True).order_by(User.last_name.asc())
    ).all()
    period = date.today().strftime("%Y-%m")
    return templates.TemplateResponse(
        "membership_consume.html",
        {"request": request, "me": me, "students": students, "period": period, "error": None, "ok": None},
    )


@router.post("/admin/memberships/consume", response_class=HTMLResponse)
def consume_do(
    request: Request,
    student_id: int = Form(...),
    service: str = Form(...),
    used_at: str = Form(""),
    used_time: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    students = db.scalars(
        select(User).where(User.role == Role.ALUMNO, User.is_active == True).order_by(User.last_name.asc())
    ).all()

    s = db.get(User, student_id)
    if (not s) or (s.role != Role.ALUMNO):
        return templates.TemplateResponse(
            "membership_consume.html",
            {"request": request, "me": me, "students": students, "period": date.today().strftime("%Y-%m"),
             "error": "Alumno inválido.", "ok": None},
        )

    d = date.today()
    if used_at.strip():
        d = datetime.strptime(used_at.strip(), "%Y-%m-%d").date()

    if d.weekday() == 6:
        return templates.TemplateResponse(
            "membership_consume.html",
            {"request": request, "me": me, "students": students, "period": date.today().strftime("%Y-%m"),
             "error": "No se puede registrar consumo en domingo (gimnasio cerrado).", "ok": None},
        )

    current_period = date.today().strftime("%Y-%m")
    period = d.strftime("%Y-%m")
    if period != current_period:
        return templates.TemplateResponse(
            "membership_consume.html",
            {"request": request, "me": me, "students": students, "period": current_period,
             "error": f"Solo se permite registrar consumos del mes actual ({current_period}).", "ok": None},
        )

    if used_time.strip():
        try:
            hh, mm = used_time.strip().split(":")
            t = dtime(int(hh), int(mm))
        except Exception:
            return templates.TemplateResponse(
                "membership_consume.html",
                {"request": request, "me": me, "students": students, "period": current_period,
                 "error": "Hora inválida. Usá HH:MM (ej: 07:30).", "ok": None},
            )
    else:
        now_t = datetime.now().time()
        t = dtime(now_t.hour, now_t.minute)

    if not (dtime(7, 0) <= t <= dtime(22, 0)):
        return templates.TemplateResponse(
            "membership_consume.html",
            {"request": request, "me": me, "students": students, "period": current_period,
             "error": "Fuera de horario. Solo 07:00 a 22:00.", "ok": None},
        )

    svc = ServiceKind(service)

    a = db.scalars(
        select(MembershipAssignment)
        .where(
            MembershipAssignment.student_id == s.id,
            MembershipAssignment.is_active == True,
            MembershipAssignment.period_yyyymm == current_period,
        )
        .order_by(MembershipAssignment.created_at.desc())
        .options(joinedload(MembershipAssignment.membership))
    ).first()

    if not a:
        return templates.TemplateResponse(
            "membership_consume.html",
            {"request": request, "me": me, "students": students, "period": current_period,
             "error": f"El alumno no tiene membresía activa para {current_period}.", "ok": None},
        )

    dup = db.scalar(
        select(MembershipUsage.id).where(
            MembershipUsage.student_id == s.id,
            MembershipUsage.used_at == d,
            MembershipUsage.service == svc,
        ).limit(1)
    )
    if dup:
        return templates.TemplateResponse(
            "membership_consume.html",
            {"request": request, "me": me, "students": students, "period": current_period,
             "error": f"Ya existe un consumo de {svc.value} para {s.full_name} en {d}.", "ok": None},
        )

    m = a.membership

    if svc == ServiceKind.FUNCIONAL:
        unlimited = bool(m.funcional_unlimited)
        allowed = None if unlimited else (m.funcional_classes or 0)
    else:
        unlimited = bool(m.musculacion_unlimited)
        allowed = None if unlimited else (m.musculacion_classes or 0)

    used_count = db.scalar(
        select(func.count(MembershipUsage.id)).where(
            MembershipUsage.student_id == s.id,
            MembershipUsage.period_yyyymm == current_period,
            MembershipUsage.service == svc,
        )
    ) or 0

    if not unlimited:
        if allowed <= 0:
            return templates.TemplateResponse(
                "membership_consume.html",
                {"request": request, "me": me, "students": students, "period": current_period,
                 "error": f"No hay cupo configurado para {svc.value} en la membresía.", "ok": None},
            )
        if used_count >= allowed:
            return templates.TemplateResponse(
                "membership_consume.html",
                {"request": request, "me": me, "students": students, "period": current_period,
                 "error": f"Cupo agotado para {svc.value}. Usadas {used_count}/{allowed}.", "ok": None},
            )

    u = MembershipUsage(
        assignment_id=a.id,
        student_id=s.id,
        service=svc,
        used_at=d,
        used_at_time=t,
        period_yyyymm=current_period,
        notes=(notes or "").strip(),
        created_by=me.id,
    )
    db.add(u)
    db.commit()

    return templates.TemplateResponse(
        "membership_consume.html",
        {"request": request, "me": me, "students": students, "period": current_period,
         "error": None, "ok": f"OK: registrado {svc.value} para {s.full_name} ({d} {t.strftime('%H:%M')})."},
    )


# =========================
# REPORTE MENSUAL
# =========================

@router.get("/admin/memberships/report", response_class=HTMLResponse)
def report_page(
    request: Request,
    period: str = "",
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    if not period.strip():
        period = date.today().strftime("%Y-%m")

    assigns = db.scalars(
        select(MembershipAssignment)
        .where(MembershipAssignment.period_yyyymm == period, MembershipAssignment.is_active == True)
        .order_by(MembershipAssignment.id.desc())
        .options(joinedload(MembershipAssignment.student), joinedload(MembershipAssignment.membership))
    ).all()

    rows = []
    for a in assigns:
        s = a.student
        m = a.membership

        used_f = db.scalar(select(func.count(MembershipUsage.id)).where(
            MembershipUsage.student_id == s.id,
            MembershipUsage.period_yyyymm == period,
            MembershipUsage.service == ServiceKind.FUNCIONAL
        )) or 0

        used_m = db.scalar(select(func.count(MembershipUsage.id)).where(
            MembershipUsage.student_id == s.id,
            MembershipUsage.period_yyyymm == period,
            MembershipUsage.service == ServiceKind.MUSCULACION
        )) or 0

        rem_f = "Libre" if m.funcional_unlimited else (m.funcional_classes or 0) - used_f
        rem_m = "Libre" if m.musculacion_unlimited else (m.musculacion_classes or 0) - used_m

        rows.append({
            "student": s,
            "membership": m,
            "used_f": used_f,
            "used_m": used_m,
            "rem_f": rem_f,
            "rem_m": rem_m,
        })

    return templates.TemplateResponse(
        "membership_report.html",
        {"request": request, "me": me, "period": period, "rows": rows},
    )

@router.get("/admin/qr", response_class=HTMLResponse)
def admin_qr_page(
    request: Request,
    service: str = "FUNCIONAL",
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED)),
):
    service = (service or "").upper().strip()
    if service not in ("FUNCIONAL", "MUSCULACION"):
        service = "FUNCIONAL"

    payload = qr_make_payload(service=service, d=date.today())

    return templates.TemplateResponse(
        "admin_qr.html",
        {
            "request": request,
            "me": me,
            "service": service,
            "payload": payload,
        },
    )