import re
from pathlib import Path
from collections import defaultdict
from datetime import datetime, date, time as dtime
from calendar import monthrange

from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, selectinload, joinedload
from sqlalchemy import select, func

from ..db import get_db
from ..deps import require_roles
from ..models import RoutineAssignment, Routine, RoutineItem, RoutineType,  MembershipAssignment, Membership, MembershipPrice, PaymentMethod, MembershipUsage, ServiceKind
from ..security import qr_verify_payload

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parents[1]  # .../app
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

ALUM_ONLY = ["ALUMNO"]

def _day_number(label: str) -> int:
    if not label:
        return 999
    m = re.search(r"(\d+)", label)
    return int(m.group(1)) if m else 999

def _has_present_today(db: Session, student_id: int) -> bool:
    today = date.today()
    found = db.scalar(
        select(MembershipUsage.id)
        .where(MembershipUsage.student_id == student_id, MembershipUsage.used_at == today)
        .limit(1)
    )
    return bool(found)


def _group_items(routine: Routine):
    """
    Devuelve una lista de grupos para mostrar en pantalla.
    - DIAS: agrupa por weekday (Lunes, Martes, ...)
    - SEMANAS: agrupa por day_label (Semana 1, Semana 2, ...) y dentro por weekday
    """
    items = list(routine.items or [])
    items.sort(key=lambda it: ((it.day_label or ""), (it.weekday or ""), it.order_index or 0, it.id))

    if routine.routine_type == RoutineType.SEMANAS:
        # Grupo principal: Semana X
        weeks = defaultdict(list)
        for it in items:
            weeks[it.day_label or "Semana"].append(it)

        groups = []
        for wk_label in sorted(weeks.keys()):
            wk_items = weeks[wk_label]
            # sub-grupo por día
            by_day = defaultdict(list)
            for it in wk_items:
                by_day[it.weekday or "Día"].append(it)

            subgroups = []
            for day in sorted(by_day.keys(), key=_day_number):
                rows = by_day[day]
                rows.sort(key=lambda it: (it.order_index or 0, it.id))
                subgroups.append({"label": day, "rows": rows})

            groups.append({"label": wk_label, "subgroups": subgroups})
        return {"mode": "SEMANAS", "groups": groups}

    # DIAS: grupo por weekday
    by_day = defaultdict(list)
    for it in items:
        by_day[it.weekday or "Día"].append(it)

    groups = []
    for day in sorted(by_day.keys(), key=_day_number):
        rows = by_day[day]
        rows.sort(key=lambda it: (it.order_index or 0, it.id))
        groups.append({"label": day, "rows": rows})

    return {"mode": "DIAS", "groups": groups}


@router.get("/alumno/rutina", response_class=HTMLResponse)
def alumno_rutina_activa(
    request: Request,
    db: Session = Depends(get_db),
    me=Depends(require_roles(ALUM_ONLY)),
):
    if not _has_present_today(db, me.id):
    # No dio presente → lo mandamos al escáner
        return RedirectResponse(url="/alumno/app?need=1", status_code=302)
    stmt = (
        select(RoutineAssignment)
        .where(
            RoutineAssignment.student_id == me.id,
            RoutineAssignment.is_active == True,
        )
        .order_by(RoutineAssignment.created_at.desc())
        .options(
            joinedload(RoutineAssignment.professor),
            selectinload(RoutineAssignment.routine).selectinload(Routine.items).joinedload(RoutineItem.exercise),
        )
    )

    assignment = db.scalars(stmt).first()

    if not assignment:
        return templates.TemplateResponse(
            "alumno_rutina.html",
            {
                "request": request,
                "me": me,
                "assignment": None,
                "routine": None,
                "view": None,
                "msg": "Todavía no tenés una rutina activa asignada.",
            },
        )

    routine = assignment.routine
    view = _group_items(routine)

    return templates.TemplateResponse(
        "alumno_rutina.html",
        {
            "request": request,
            "me": me,
            "assignment": assignment,
            "routine": routine,
            "view": view,
            "msg": None,
        },
    )

@router.get("/alumno/membresia", response_class=HTMLResponse)
def alumno_membresia(
    request: Request,
    db: Session = Depends(get_db),
    me=Depends(require_roles(["ALUMNO"])),
):
    period = date.today().strftime("%Y-%m")

    a = db.scalars(
        select(MembershipAssignment)
        .where(
            MembershipAssignment.student_id == me.id,
            MembershipAssignment.is_active == True,
            MembershipAssignment.period_yyyymm == period,
        )
        .order_by(MembershipAssignment.created_at.desc())
        .options(joinedload(MembershipAssignment.membership))
    ).first()

    if not a:
        return templates.TemplateResponse(
            "alumno_membresia.html",
            {
                "request": request,
                "me": me,
                "assignment": None,
                "membership": None,
                "period": period,
                "prices": {},
            },
        )

    m = a.membership

    # precios actuales (lista/efectivo) por si querés mostrarlos
    prices_rows = db.scalars(
        select(MembershipPrice).where(MembershipPrice.membership_id == m.id)
    ).all()
    prices = {p.payment_method.value: float(p.amount) for p in prices_rows}

    return templates.TemplateResponse(
        "alumno_membresia.html",
        {
            "request": request,
            "me": me,
            "assignment": a,
            "membership": m,
            "period": period,
            "prices": prices,
        },
    )

@router.post("/api/alumno/checkin")
def alumno_checkin(
    qr: str = Form(...),
    db: Session = Depends(get_db),
    me=Depends(require_roles(["ALUMNO"])),
):
    ok, service_str, d_qr = qr_verify_payload(qr)
    if not ok:
        return JSONResponse({"ok": False, "error": "QR inválido."}, status_code=400)

    # QR solo válido para HOY
    today = date.today()
    if d_qr != today:
        return JSONResponse({"ok": False, "error": "QR vencido (no corresponde a hoy)."}, status_code=400)

    # horario y domingo
    if today.weekday() == 6:
        return JSONResponse({"ok": False, "error": "Domingo: gimnasio cerrado."}, status_code=400)

    now_t = datetime.now().time()
    t = dtime(now_t.hour, now_t.minute)
    if not (dtime(7, 0) <= t <= dtime(22, 0)):
        return JSONResponse({"ok": False, "error": "Fuera de horario (07:00–22:00)."}, status_code=400)

    period = today.strftime("%Y-%m")
    svc = ServiceKind.FUNCIONAL if service_str == "FUNCIONAL" else ServiceKind.MUSCULACION

    # membresía activa del mes
    a = db.scalars(
        select(MembershipAssignment)
        .where(
            MembershipAssignment.student_id == me.id,
            MembershipAssignment.is_active == True,
            MembershipAssignment.period_yyyymm == period,
        )
        .order_by(MembershipAssignment.created_at.desc())
        .options(joinedload(MembershipAssignment.membership))
    ).first()

    if not a:
        return JSONResponse({"ok": False, "error": f"No tenés membresía activa para {period}."}, status_code=400)

    # no duplicado mismo día y servicio
    dup = db.scalar(
        select(MembershipUsage.id).where(
            MembershipUsage.student_id == me.id,
            MembershipUsage.used_at == today,
            MembershipUsage.service == svc,
        ).limit(1)
    )
    if dup:
        return JSONResponse({"ok": False, "error": "Ya registraste asistencia hoy para ese servicio."}, status_code=400)

    m = a.membership

    # cupos
    if svc == ServiceKind.FUNCIONAL:
        unlimited = bool(m.funcional_unlimited)
        allowed = None if unlimited else (m.funcional_classes or 0)
    else:
        unlimited = bool(m.musculacion_unlimited)
        allowed = None if unlimited else (m.musculacion_classes or 0)

    used_count = db.scalar(
        select(func.count(MembershipUsage.id)).where(
            MembershipUsage.student_id == me.id,
            MembershipUsage.period_yyyymm == period,
            MembershipUsage.service == svc,
        )
    ) or 0

    if not unlimited:
        if allowed <= 0:
            return JSONResponse({"ok": False, "error": "Tu membresía no tiene cupo para este servicio."}, status_code=400)
        if used_count >= allowed:
            return JSONResponse({"ok": False, "error": "Cupo agotado para este servicio."}, status_code=400)

    # registrar uso
    u = MembershipUsage(
        assignment_id=a.id,
        student_id=me.id,
        service=svc,
        used_at=today,
        used_at_time=t,
        period_yyyymm=period,
        notes="Check-in QR (alumno)",
        created_by=me.id,
    )
    db.add(u)
    db.commit()

    # devolver nuevos contadores
    used_new = used_count + 1
    remaining = "Libre" if unlimited else max(0, allowed - used_new)

    return {"ok": True, "service": service_str, "period": period, "used": used_new, "allowed": (None if unlimited else allowed), "remaining": remaining}

@router.get("/alumno/app", response_class=HTMLResponse)
def alumno_app(
    request: Request,
    db: Session = Depends(get_db),
    me=Depends(require_roles(["ALUMNO"])),
):
    today = date.today()
    period = today.strftime("%Y-%m")

    # ✅ banner primero
    banner = None

    # Si vino porque quiso entrar a la rutina sin presente
    need = request.query_params.get("need")
    if need == "1":
        banner = "📌 Primero tenés que escanear el QR para dar presente. Después se habilita tu rutina."

    a = db.scalars(
        select(MembershipAssignment)
        .where(
            MembershipAssignment.student_id == me.id,
            MembershipAssignment.is_active == True,
            MembershipAssignment.period_yyyymm == period,
        )
        .order_by(MembershipAssignment.created_at.desc())
        .options(joinedload(MembershipAssignment.membership))
    ).first()

    funcional_rem = "-"
    muscu_rem = "-"

    # aviso 1 semana antes de fin de mes (si no hay otro banner más importante)
    last_day = monthrange(today.year, today.month)[1]
    days_left = last_day - today.day
    if days_left <= 7:
        banner = banner or f"⚠️ Faltan {days_left} días para que termine el mes. Recordá usar tus clases."

    if a:
        m = a.membership

        used_f = db.scalar(
            select(func.count(MembershipUsage.id)).where(
                MembershipUsage.student_id == me.id,
                MembershipUsage.period_yyyymm == period,
                MembershipUsage.service == ServiceKind.FUNCIONAL,
            )
        ) or 0

        used_m = db.scalar(
            select(func.count(MembershipUsage.id)).where(
                MembershipUsage.student_id == me.id,
                MembershipUsage.period_yyyymm == period,
                MembershipUsage.service == ServiceKind.MUSCULACION,
            )
        ) or 0

        if m.funcional_unlimited:
            funcional_rem = "Libre"
        else:
            total_f = m.funcional_classes or 0
            funcional_rem = max(0, total_f - used_f)
            if total_f > 0 and funcional_rem <= 2:
                banner = banner or "⚠️ Te quedan pocas clases de Funcional. Aprovechalas antes de fin de mes."

        if m.musculacion_unlimited:
            muscu_rem = "Libre"
        else:
            total_m = m.musculacion_classes or 0
            muscu_rem = max(0, total_m - used_m)
            if total_m > 0 and muscu_rem <= 2:
                banner = banner or "⚠️ Te quedan pocas clases de Musculación. Aprovechalas antes de fin de mes."

    return templates.TemplateResponse(
        "alumno_app.html",
        {
            "request": request,
            "me": me,
            "period": period,
            "funcional_rem": funcional_rem,
            "muscu_rem": muscu_rem,
            "banner": banner,
        },
    )