from .db import engine, Base
from .routers import auth, admin_users, profesor, alumno

from fastapi.staticfiles import StaticFiles
from fastapi import FastAPI, Request
from .deps import _RedirectToLogin, redirect_to_login_handler
from .routers import profesor
from .routers import alumno
from .routers import admin_memberships


app = FastAPI(title="TRZ Gym")
app.add_exception_handler(_RedirectToLogin, redirect_to_login_handler)
app.mount("/static", StaticFiles(directory="app/static"), name="static")

# Crea tablas si no existen (no migra columnas; para eso usás el SQL de migración)
Base.metadata.create_all(bind=engine)

app.include_router(auth.router)
app.include_router(admin_users.router)
app.include_router(profesor.router)
app.include_router(alumno.router)
app.include_router(admin_memberships.router)

@app.get("/")
def root():
    return {"ok": True, "go": "/login"}