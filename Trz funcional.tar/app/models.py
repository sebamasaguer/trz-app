import enum
from datetime import datetime, date, time

from sqlalchemy import String, DateTime, Boolean, Enum as SAEnum, Date, ForeignKey, Integer, Numeric
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func


from .db import Base


class RoutineType(str, enum.Enum):
    DIAS = "DIAS"
    SEMANAS = "SEMANAS"


class Role(str, enum.Enum):
    ADMINISTRADOR = "ADMINISTRADOR"
    ADMINISTRATIVO = "ADMINISTRATIVO"
    PROFESOR = "PROFESOR"
    ALUMNO = "ALUMNO"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)

    first_name: Mapped[str] = mapped_column(String(120), default="")
    last_name: Mapped[str] = mapped_column(String(120), default="")
    dni: Mapped[str | None] = mapped_column(String(20), unique=True, nullable=True)
    birth_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    address: Mapped[str] = mapped_column(String(255), default="")
    phone: Mapped[str] = mapped_column(String(30), default="")
    emergency_contact_name: Mapped[str] = mapped_column(String(120), default="")
    emergency_contact_phone: Mapped[str] = mapped_column(String(30), default="")

    full_name: Mapped[str] = mapped_column(String(255), default="")

    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[Role] = mapped_column(SAEnum(Role, name="role_enum"), default=Role.ALUMNO)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    must_change_password: Mapped[bool] = mapped_column(Boolean, default=False)

    @property
    def age(self) -> int | None:
        if not self.birth_date:
            return None
        today = date.today()
        years = today.year - self.birth_date.year
        if (today.month, today.day) < (self.birth_date.month, self.birth_date.day):
            years -= 1
        return years


class Exercise(Base):
    __tablename__ = "exercises"

    id: Mapped[int] = mapped_column(primary_key=True)
    professor_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)

    name: Mapped[str] = mapped_column(String(180))
    description: Mapped[str] = mapped_column(String(1000), default="")
    muscle_group: Mapped[str] = mapped_column(String(120), default="")
    equipment: Mapped[str] = mapped_column(String(120), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    professor = relationship("User", lazy="joined")


class Routine(Base):
    __tablename__ = "routines"

    id: Mapped[int] = mapped_column(primary_key=True)
    professor_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)

    title: Mapped[str] = mapped_column(String(180))
    notes: Mapped[str] = mapped_column(String(2000), default="")
    routine_type: Mapped[RoutineType] = mapped_column(SAEnum(RoutineType, name="routine_type"), default=RoutineType.DIAS)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    professor = relationship("User", lazy="joined")
    items = relationship("RoutineItem", cascade="all, delete-orphan", back_populates="routine")


class RoutineItem(Base):
    __tablename__ = "routine_items"

    id: Mapped[int] = mapped_column(primary_key=True)
    routine_id: Mapped[int] = mapped_column(ForeignKey("routines.id", ondelete="CASCADE"), index=True)
    exercise_id: Mapped[int] = mapped_column(ForeignKey("exercises.id", ondelete="RESTRICT"), index=True)

    # "Semana 1" cuando routine_type = SEMANAS
    day_label: Mapped[str] = mapped_column(String(30), default="")

    # día de la semana
    weekday: Mapped[str] = mapped_column(String(12), default="")

    sets: Mapped[int] = mapped_column(Integer, default=0)
    reps: Mapped[str] = mapped_column(String(50), default="")
    rest_seconds: Mapped[int] = mapped_column(Integer, default=0)
    order_index: Mapped[int] = mapped_column(Integer, default=0)
    notes: Mapped[str] = mapped_column(String(500), default="")

    routine = relationship("Routine", back_populates="items")
    exercise = relationship("Exercise", lazy="joined")


class RoutineAssignment(Base):
    __tablename__ = "routine_assignments"

    id: Mapped[int] = mapped_column(primary_key=True)
    routine_id: Mapped[int] = mapped_column(ForeignKey("routines.id", ondelete="CASCADE"), index=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    assigned_by: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))

    start_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    routine = relationship("Routine", lazy="joined")
    student = relationship("User", foreign_keys=[student_id], lazy="joined")
    professor = relationship("User", foreign_keys=[assigned_by], lazy="joined")


class ProfesorAlumno(Base):
    __tablename__ = "profesor_alumnos"

    id: Mapped[int] = mapped_column(primary_key=True)
    profesor_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    alumno_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    profesor = relationship("User", foreign_keys=[profesor_id], lazy="joined")
    alumno = relationship("User", foreign_keys=[alumno_id], lazy="joined")

class MembershipKind(str, enum.Enum):
    FUNCIONAL = "FUNCIONAL"
    MUSCULACION = "MUSCULACION"
    COMBINACION = "COMBINACION"
    CLASE_SUELTA = "CLASE_SUELTA"


class PaymentMethod(str, enum.Enum):
    LISTA = "LISTA"
    EFECTIVO = "EFECTIVO"


class Membership(Base):
    __tablename__ = "memberships"

    id: Mapped[int] = mapped_column(primary_key=True)

    name: Mapped[str] = mapped_column(String(180))
    kind: Mapped[MembershipKind] = mapped_column(SAEnum(MembershipKind, name="membership_kind"))

    funcional_classes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    musculacion_classes: Mapped[int | None] = mapped_column(Integer, nullable=True)

    funcional_unlimited: Mapped[bool] = mapped_column(Boolean, default=False)
    musculacion_unlimited: Mapped[bool] = mapped_column(Boolean, default=False)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    prices: Mapped[list["MembershipPrice"]] = relationship(
        back_populates="membership",
        cascade="all, delete-orphan",
    )


class MembershipPrice(Base):
    __tablename__ = "membership_prices"

    id: Mapped[int] = mapped_column(primary_key=True)
    membership_id: Mapped[int] = mapped_column(ForeignKey("memberships.id", ondelete="CASCADE"), index=True)

    payment_method: Mapped[PaymentMethod] = mapped_column(SAEnum(PaymentMethod, name="payment_method"))
    amount: Mapped[float] = mapped_column(Numeric(12, 2))

    membership: Mapped["Membership"] = relationship(back_populates="prices")


class MembershipAssignment(Base):
    __tablename__ = "membership_assignments"

    id: Mapped[int] = mapped_column(primary_key=True)

    membership_id: Mapped[int] = mapped_column(ForeignKey("memberships.id", ondelete="CASCADE"), index=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    assigned_by: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))

    start_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    payment_method: Mapped[PaymentMethod | None] = mapped_column(
        SAEnum(PaymentMethod, name="payment_method"), nullable=True
    )
    amount_snapshot: Mapped[float | None] = mapped_column(Numeric(12, 2), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    membership: Mapped["Membership"] = relationship()
    student: Mapped["User"] = relationship(foreign_keys=[student_id])
    assigned_by_user: Mapped["User"] = relationship(foreign_keys=[assigned_by])
    period_yyyymm: Mapped[str | None] = mapped_column(String(7), nullable=True)

import enum
from sqlalchemy import Enum as SAEnum
from sqlalchemy.sql import func

class ServiceKind(str, enum.Enum):
    FUNCIONAL = "FUNCIONAL"
    MUSCULACION = "MUSCULACION"


class MembershipUsage(Base):
    __tablename__ = "membership_usages"

    id: Mapped[int] = mapped_column(primary_key=True)

    assignment_id: Mapped[int] = mapped_column(ForeignKey("membership_assignments.id", ondelete="CASCADE"), index=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)

    service: Mapped[ServiceKind] = mapped_column(SAEnum(ServiceKind, name="service_kind"))

    used_at: Mapped[date] = mapped_column(Date, nullable=False)
    used_at_time: Mapped[time | None] = mapped_column(nullable=True)
    period_yyyymm: Mapped[str] = mapped_column(String(7), index=True)

    notes: Mapped[str] = mapped_column(String(255), default="")
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    assignment: Mapped["MembershipAssignment"] = relationship()
    student: Mapped["User"] = relationship(foreign_keys=[student_id])
    created_by_user: Mapped["User"] = relationship(foreign_keys=[created_by])
