from pathlib import Path
from datetime import datetime, date, time

from fastapi import APIRouter, Request, Depends, Form, Query
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import select, func, or_

from ..db import get_db
from ..deps import require_roles
from ..models import (
    User, Role,
    CashSession, CashSessionStatus,
    CashMovement, CashEntryType, CashPaymentStatus,
    CashExpenseCategory, PaymentMethod
)

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parents[1]
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


def money(v) -> float:
    return float(v or 0)


def get_open_cash_session(db: Session) -> CashSession | None:
    return db.scalar(
        select(CashSession)
        .where(CashSession.status == CashSessionStatus.ABIERTA)
        .options(
            joinedload(CashSession.opened_by),
            joinedload(CashSession.movements),
        )
        .order_by(CashSession.opened_at.desc())
    )


def sync_cash_session_totals(db: Session, cash_session: CashSession) -> None:
    income = db.scalar(
        select(func.coalesce(func.sum(CashMovement.amount), 0))
        .where(
            CashMovement.session_id == cash_session.id,
            CashMovement.entry_type == CashEntryType.INGRESO,
            CashMovement.status == CashPaymentStatus.ACREDITADO
        )
    ) or 0

    expense = db.scalar(
        select(func.coalesce(func.sum(CashMovement.amount), 0))
        .where(
            CashMovement.session_id == cash_session.id,
            CashMovement.entry_type == CashEntryType.EGRESO,
            CashMovement.status == CashPaymentStatus.ACREDITADO,
        )
    ) or 0

    cash_session.total_income = income
    cash_session.total_expense = expense
    cash_session.expected_closing_amount = money(cash_session.opening_amount) + money(income) - money(expense)


def register_cash_income(
    db: Session,
    *,
    concept: str,
    amount: float,
    payment_method: PaymentMethod | None,
    created_by_id: int,
    student_id: int | None = None,
    category: str = "MEMBRESIA",
    movement_date: datetime | None = None,
    description: str | None = None,
    status: CashPaymentStatus = CashPaymentStatus.ACREDITADO,
) -> CashMovement:
    cash_session = get_open_cash_session(db)
    if not cash_session:
        raise ValueError("No hay caja abierta.")

    movement = CashMovement(
        session_id=cash_session.id,
        entry_type=CashEntryType.INGRESO,
        category=category,
        concept=concept,
        amount=amount,
        payment_method=payment_method,
        student_id=student_id,
        created_by_id=created_by_id,
        movement_date=movement_date or datetime.utcnow(),
        description=description,
        status=status,
    )
    db.add(movement)
    db.flush()

    sync_cash_session_totals(db, cash_session)
    db.flush()
    return movement


@router.get("", response_class=HTMLResponse)
def cash_dashboard(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles([Role.ADMINISTRADOR, Role.ADMINISTRATIVO])),
    q: str = "",
    month: str = "",
    status: str = "",
    payment_method: str = "",
):
    open_session = get_open_cash_session(db)

    stmt = (
        select(CashMovement)
        .options(
            joinedload(CashMovement.student),
            joinedload(CashMovement.created_by),
            joinedload(CashMovement.session),
        )
        .order_by(CashMovement.movement_date.desc())
    )

    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.join(User, CashMovement.student_id == User.id, isouter=True).where(
            or_(
                CashMovement.concept.ilike(like),
                User.first_name.ilike(like),
                User.last_name.ilike(like),
                User.email.ilike(like),
                User.dni.ilike(like),
            )
        )

    if month:
        try:
            y, m = month.split("-")
            y = int(y)
            m = int(m)
            start_dt = datetime(y, m, 1)
            if m == 12:
                end_dt = datetime(y + 1, 1, 1)
            else:
                end_dt = datetime(y, m + 1, 1)
            stmt = stmt.where(
                CashMovement.movement_date >= start_dt,
                CashMovement.movement_date < end_dt,
            )
        except Exception:
            pass

    if status:
        stmt = stmt.where(CashMovement.status == status)

    if payment_method:
        stmt = stmt.where(CashMovement.payment_method == payment_method)

    movements = db.scalars(stmt.limit(200)).all()

    accredited_total = sum(
        money(m.amount)
        for m in movements
        if m.status == CashPaymentStatus.ACREDITADO and m.entry_type == CashEntryType.INGRESO
    )
    pending_total = sum(
        money(m.amount)
        for m in movements
        if m.status == CashPaymentStatus.PENDIENTE and m.entry_type == CashEntryType.INGRESO
    )
    expense_total = sum(
        money(m.amount)
        for m in movements
        if m.status == CashPaymentStatus.ACREDITADO and m.entry_type == CashEntryType.EGRESO
    )

    sessions = db.scalars(
        select(CashSession)
        .options(joinedload(CashSession.opened_by), joinedload(CashSession.closed_by))
        .order_by(CashSession.opened_at.desc())
        .limit(10)
    ).all()

    return templates.TemplateResponse(
        "cash_dashboard.html",
        {
            "request": request,
            "me": me,
            "q": q,
            "month": month,
            "status": status,
            "payment_method": payment_method,
            "movements": movements,
            "open_session": open_session,
            "sessions": sessions,
            "accredited_total": accredited_total,
            "pending_total": pending_total,
            "expense_total": expense_total,
            "payment_methods": list(PaymentMethod),
            "movement_statuses": list(CashPaymentStatus),
        },
    )


@router.get("/open", response_class=HTMLResponse)
def cash_open_form(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles([Role.ADMINISTRADOR, Role.ADMINISTRATIVO])),
):
    open_session = get_open_cash_session(db)
    return templates.TemplateResponse(
        "cash_open.html",
        {
            "request": request,
            "me": me,
            "open_session": open_session,
            "error": "",
        },
    )


@router.post("/open")
def cash_open_post(
    request: Request,
    opening_amount: float = Form(0),
    description: str = Form(""),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles([Role.ADMINISTRADOR, Role.ADMINISTRATIVO])),
):
    current_open = get_open_cash_session(db)
    if current_open:
        return RedirectResponse("/admin/caja?error=Ya+hay+una+caja+abierta", status_code=303)

    new_session = CashSession(
        status=CashSessionStatus.ABIERTA,
        opened_at=datetime.utcnow(),
        opened_by_user_id=me.id,
        opening_amount=opening_amount or 0,
        total_income=0,
        total_expense=0,
        expected_closing_amount=opening_amount or 0,
        description=description.strip() or None,
    )
    db.add(new_session)
    db.commit()

    return RedirectResponse("/admin/caja?ok=Caja+abierta+correctamente", status_code=303)


@router.get("/expense/new", response_class=HTMLResponse)
def cash_expense_form(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles([Role.ADMINISTRADOR, Role.ADMINISTRATIVO])),
):
    open_session = get_open_cash_session(db)
    return templates.TemplateResponse(
        "cash_expense_form.html",
        {
            "request": request,
            "me": me,
            "open_session": open_session,
            "categories": list(CashExpenseCategory),
            "payment_methods": list(PaymentMethod),
            "error": "",
        },
    )


@router.post("/expense/new")
def cash_expense_post(
    concept: str = Form(...),
    amount: float = Form(...),
    category: str = Form(...),
    payment_method: str = Form(""),
    movement_date: str = Form(""),
    movement_time: str = Form(""),
    description: str = Form(""),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles([Role.ADMINISTRADOR, Role.ADMINISTRATIVO])),
):
    open_session = get_open_cash_session(db)
    if not open_session:
        return RedirectResponse("/admin/caja?error=No+hay+una+caja+abierta", status_code=303)

    dt = datetime.utcnow()
    if movement_date:
        try:
            d = date.fromisoformat(movement_date)
            t = time.fromisoformat(movement_time) if movement_time else time(0, 0)
            dt = datetime.combine(d, t)
        except Exception:
            pass

    movement = CashMovement(
        session_id=open_session.id,
        entry_type=CashEntryType.EGRESO,
        category=category,
        concept=concept.strip(),
        description=description.strip() or "",
        amount=amount,
        payment_method=PaymentMethod(payment_method) if payment_method else None,
        status=CashPaymentStatus.ACREDITADO,
        student_id=None,
        created_by_id=me.id,
        movement_date=dt,
        receipt_note="",
    )
    db.add(movement)
    db.flush()

    sync_cash_session_totals(db, open_session)
    db.commit()

    return RedirectResponse("/admin/caja?ok=Egreso+registrado+correctamente", status_code=303)


@router.get("/close", response_class=HTMLResponse)
def cash_close_form(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles([Role.ADMINISTRADOR, Role.ADMINISTRATIVO])),
):
    open_session = get_open_cash_session(db)
    if open_session:
        sync_cash_session_totals(db, open_session)
        db.commit()

    movements = []
    if open_session:
        movements = db.scalars(
            select(CashMovement)
            .where(CashMovement.session_id == open_session.id)
            .options(joinedload(CashMovement.student), joinedload(CashMovement.created_by))
            .order_by(CashMovement.movement_date.asc())
        ).all()

    return templates.TemplateResponse(
        "cash_close.html",
        {
            "request": request,
            "me": me,
            "open_session": open_session,
            "movements": movements,
            "error": "",
        },
    )


@router.post("/close")
def cash_close_post(
    real_closing_amount: float = Form(...),
    notes: str = Form(""),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles([Role.ADMINISTRADOR, Role.ADMINISTRATIVO])),
):
    open_session = get_open_cash_session(db)
    if not open_session:
        return RedirectResponse("/admin/caja?error=No+hay+una+caja+abierta", status_code=303)

    sync_cash_session_totals(db, open_session)

    expected = money(open_session.expected_closing_amount)
    real = money(real_closing_amount)

    open_session.real_closing_amount = real
    open_session.difference_amount = real - expected
    open_session.closed_at = datetime.utcnow()
    open_session.closed_by_user_id = me.id
    open_session.status = CashSessionStatus.CERRADA
    open_session.notes = ((open_session.notes or "") + "\n" + notes.strip()).strip()

    db.commit()

    return RedirectResponse("/admin/caja?ok=Caja+cerrada+correctamente", status_code=303)


@router.get("/report", response_class=HTMLResponse)
def cash_report(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles([Role.ADMINISTRADOR, Role.ADMINISTRATIVO])),
    date_from: str = Query(""),
    date_to: str = Query(""),
    entry_type: str = Query(""),
    payment_method: str = Query(""),
    category: str = Query(""),
    user_q: str = Query(""),
):
    stmt = (
        select(CashMovement)
        .options(
            joinedload(CashMovement.student),
            joinedload(CashMovement.created_by),
            joinedload(CashMovement.session),
        )
        .order_by(CashMovement.movement_date.desc())
    )

    if date_from:
        try:
            stmt = stmt.where(CashMovement.movement_date >= datetime.combine(date.fromisoformat(date_from), time.min))
        except Exception:
            pass

    if date_to:
        try:
            stmt = stmt.where(CashMovement.movement_date <= datetime.combine(date.fromisoformat(date_to), time.max))
        except Exception:
            pass

    if entry_type:
        stmt = stmt.where(CashMovement.entry_type == entry_type)

    if payment_method:
        stmt = stmt.where(CashMovement.payment_method == payment_method)

    if category:
        stmt = stmt.where(CashMovement.category == category)

    if user_q:
        like = f"%{user_q.strip()}%"
        stmt = stmt.join(User, CashMovement.created_by_id == User.id).where(
            or_(
                User.first_name.ilike(like),
                User.last_name.ilike(like),
                User.email.ilike(like),
            )
        )

    movements = db.scalars(stmt).all()

    total_income = sum(
        money(m.amount)
        for m in movements
        if m.entry_type == CashEntryType.INGRESO and m.status == CashPaymentStatus.ACREDITADO
    )
    total_expense = sum(
        money(m.amount)
        for m in movements
        if m.entry_type == CashEntryType.EGRESO and m.status == CashPaymentStatus.ACREDITADO
    )
    net_total = total_income - total_expense

    sessions_stmt = (
        select(CashSession)
        .options(joinedload(CashSession.opened_by), joinedload(CashSession.closed_by))
        .order_by(CashSession.opened_at.desc())
    )

    if date_from:
        try:
            sessions_stmt = sessions_stmt.where(CashSession.opened_at >= datetime.combine(date.fromisoformat(date_from), time.min))
        except Exception:
            pass

    if date_to:
        try:
            sessions_stmt = sessions_stmt.where(CashSession.opened_at <= datetime.combine(date.fromisoformat(date_to), time.max))
        except Exception:
            pass

    sessions = db.scalars(sessions_stmt).all()

    return templates.TemplateResponse(
        "cash_report.html",
        {
            "request": request,
            "me": me,
            "date_from": date_from,
            "date_to": date_to,
            "entry_type": entry_type,
            "payment_method": payment_method,
            "category": category,
            "user_q": user_q,
            "movements": movements,
            "sessions": sessions,
            "total_income": total_income,
            "total_expense": total_expense,
            "net_total": net_total,
            "payment_methods": list(PaymentMethod),
            "expense_categories": list(CashExpenseCategory),
            "entry_type": list(CashEntryType),
        },
    )