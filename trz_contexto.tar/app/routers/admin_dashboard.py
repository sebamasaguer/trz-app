from pathlib import Path
from datetime import date, datetime, timedelta
from io import BytesIO
from collections import Counter, defaultdict

from fastapi import APIRouter, Request, Depends, Query
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import select, func

from openpyxl import Workbook

from ..db import get_db
from ..deps import require_roles
from ..models import (
    User,
    Role,
    MembershipUsage,
    MembershipAssignment,
    ProfesorAlumno,
)

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parents[1]
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


def current_period_yyyymm() -> str:
    return date.today().strftime("%Y-%m")


def months_between(last_date: date, today: date) -> int:
    return (today.year - last_date.year) * 12 + (today.month - last_date.month)


def add_months(base: date, delta: int) -> date:
    month = base.month - 1 + delta
    year = base.year + month // 12
    month = month % 12 + 1
    day = min(base.day, 28)
    return date(year, month, day)


def month_key(d: date) -> str:
    return d.strftime("%Y-%m")


def month_label(yyyymm: str) -> str:
    y, m = yyyymm.split("-")
    meses = {
        "01": "Ene", "02": "Feb", "03": "Mar", "04": "Abr",
        "05": "May", "06": "Jun", "07": "Jul", "08": "Ago",
        "09": "Sep", "10": "Oct", "11": "Nov", "12": "Dic",
    }
    return f'{meses.get(m, m)} {y}'


def parse_date_or_default(value: str, fallback: date) -> date:
    try:
        return date.fromisoformat((value or "").strip())
    except Exception:
        return fallback


def excel_response(wb: Workbook, filename: str) -> StreamingResponse:
    bio = BytesIO()
    wb.save(bio)
    bio.seek(0)
    return StreamingResponse(
        bio,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def build_dashboard_data(db: Session, date_from: date, date_to: date):
    today = date.today()
    current_period = current_period_yyyymm()

    # =========================
    # Alumnos activos
    # =========================
    alumnos = db.scalars(
        select(User)
        .where(
            User.role == Role.ALUMNO,
            User.is_active == True,
        )
        .order_by(User.last_name.asc(), User.first_name.asc(), User.email.asc())
    ).all()

    total_alumnos = len(alumnos)
    alumno_ids = [a.id for a in alumnos]

    # =========================
    # Presencias en rango y hoy
    # =========================
    presencias_hoy = db.scalar(
        select(func.count(MembershipUsage.id))
        .where(MembershipUsage.used_at == today)
    ) or 0

    usages_rango = db.scalars(
        select(MembershipUsage)
        .options(joinedload(MembershipUsage.student))
        .where(
            MembershipUsage.used_at >= date_from,
            MembershipUsage.used_at <= date_to,
        )
        .order_by(MembershipUsage.used_at.asc(), MembershipUsage.id.asc())
    ).all()

    presencias_rango = len(usages_rango)

    # =========================
    # Última asistencia por alumno
    # =========================
    last_usage_rows = db.execute(
        select(
            MembershipUsage.student_id,
            func.max(MembershipUsage.used_at).label("last_used_at")
        )
        .group_by(MembershipUsage.student_id)
    ).all()

    last_usage_map = {row.student_id: row.last_used_at for row in last_usage_rows}

    inactivos_bucket = {
        "0": [],
        "1": [],
        "2": [],
        "3": [],
        "4": [],
        "5": [],
        "6+": [],
        "nunca": [],
    }

    detalles_inactivos = []

    for alumno in alumnos:
        last_used = last_usage_map.get(alumno.id)

        if not last_used:
            inactivos_bucket["nunca"].append(alumno)
            detalles_inactivos.append({
                "alumno": alumno,
                "last_used_at": None,
                "months": None,
                "bucket": "nunca",
                "severity": "alta",
            })
            continue

        diff = months_between(last_used, today)

        if diff <= 0:
            bucket = "0"
            severity = "ok"
        elif diff == 1:
            bucket = "1"
            severity = "baja"
        elif diff == 2:
            bucket = "2"
            severity = "media"
        elif diff == 3:
            bucket = "3"
            severity = "media"
        elif diff == 4:
            bucket = "4"
            severity = "alta"
        elif diff == 5:
            bucket = "5"
            severity = "alta"
        else:
            bucket = "6+"
            severity = "critica"

        inactivos_bucket[bucket].append(alumno)
        detalles_inactivos.append({
            "alumno": alumno,
            "last_used_at": last_used,
            "months": diff,
            "bucket": bucket,
            "severity": severity,
        })

    activos_recientes = len(inactivos_bucket["0"])
    total_inactivos = sum(len(v) for k, v in inactivos_bucket.items() if k != "0")

    # =========================
    # Cuotas vencidas
    # =========================
    assignments = db.scalars(
        select(MembershipAssignment)
        .where(MembershipAssignment.is_active == True)
        .options(
            joinedload(MembershipAssignment.membership),
            joinedload(MembershipAssignment.student),
        )
        .order_by(MembershipAssignment.student_id.asc(), MembershipAssignment.id.desc())
    ).all()

    latest_assignment_by_student = {}

    for a in assignments:
        prev = latest_assignment_by_student.get(a.student_id)
        if prev is None:
            latest_assignment_by_student[a.student_id] = a
            continue

        prev_period = (prev.period_yyyymm or "").strip()
        new_period = (a.period_yyyymm or "").strip()

        if new_period > prev_period:
            latest_assignment_by_student[a.student_id] = a
        elif new_period == prev_period and a.id > prev.id:
            latest_assignment_by_student[a.student_id] = a

    cuotas_vencidas = []
    cuotas_al_dia = []

    for alumno in alumnos:
        ass = latest_assignment_by_student.get(alumno.id)

        if not ass:
            cuotas_vencidas.append({
                "alumno": alumno,
                "motivo": "Sin membresía activa asignada",
                "periodo": "-",
                "membership_name": "-",
                "severity": "alta",
            })
            continue

        ass_period = (ass.period_yyyymm or "").strip()
        membership_name = ass.membership.name if ass.membership else "-"

        if not ass_period:
            cuotas_vencidas.append({
                "alumno": alumno,
                "motivo": "Asignación sin período",
                "periodo": "-",
                "membership_name": membership_name,
                "severity": "alta",
            })
            continue

        if ass_period < current_period:
            diff_months = (
                (today.year - int(ass_period.split("-")[0])) * 12
                + (today.month - int(ass_period.split("-")[1]))
            )
            severity = "media" if diff_months == 1 else "alta"
            cuotas_vencidas.append({
                "alumno": alumno,
                "motivo": "Período vencido",
                "periodo": ass_period,
                "membership_name": membership_name,
                "severity": severity,
            })
        else:
            cuotas_al_dia.append({
                "alumno": alumno,
                "periodo": ass_period,
                "membership_name": membership_name,
            })

    # =========================
    # Últimas presencias
    # =========================
    ultimas_presencias = db.scalars(
        select(MembershipUsage)
        .options(joinedload(MembershipUsage.student))
        .order_by(MembershipUsage.created_at.desc(), MembershipUsage.id.desc())
        .limit(12)
    ).all()

    # =========================
    # Presencias por día del rango
    # =========================
    per_day_counter = Counter()
    service_counter = Counter()
    hour_counter = Counter()

    for u in usages_rango:
        per_day_counter[u.used_at.isoformat()] += 1
        service_counter[u.service.value if hasattr(u.service, "value") else str(u.service)] += 1
        if u.used_at_time:
            hour_counter[u.used_at_time.strftime("%H:%M")] += 1

    day_cursor = date_from
    presencias_por_dia = []
    while day_cursor <= date_to:
        key = day_cursor.isoformat()
        presencias_por_dia.append({
            "day": day_cursor.strftime("%d/%m"),
            "count": per_day_counter.get(key, 0),
        })
        day_cursor += timedelta(days=1)

    servicios = [
        {"label": "FUNCIONAL", "count": service_counter.get("FUNCIONAL", 0)},
        {"label": "MUSCULACION", "count": service_counter.get("MUSCULACION", 0)},
    ]

    horarios_top = sorted(
        [{"hour": k, "count": v} for k, v in hour_counter.items()],
        key=lambda x: (-x["count"], x["hour"])
    )[:10]

    # =========================
    # Comparativo mensual (últimos 6 meses)
    # =========================
    base_month = date(today.year, today.month, 1)
    months = [add_months(base_month, delta) for delta in range(-5, 1)]
    month_keys = [month_key(m) for m in months]

    monthly_counts = db.execute(
        select(
            MembershipUsage.period_yyyymm,
            func.count(MembershipUsage.id)
        )
        .where(MembershipUsage.period_yyyymm.in_(month_keys))
        .group_by(MembershipUsage.period_yyyymm)
    ).all()

    monthly_map = {row[0]: row[1] for row in monthly_counts}

    comparativo_mensual = [
        {
            "period": mk,
            "label": month_label(mk),
            "count": int(monthly_map.get(mk, 0)),
        }
        for mk in month_keys
    ]

    # =========================
    # Profesores con más asistencias
    # usando profesor_alumnos para inferencia
    # =========================
    profesor_alumno_rows = db.execute(
        select(ProfesorAlumno.profesor_id, ProfesorAlumno.alumno_id)
    ).all()

    alumno_to_profesores = defaultdict(list)
    for profesor_id, alumno_id in profesor_alumno_rows:
        alumno_to_profesores[alumno_id].append(profesor_id)

    profesor_counter = Counter()
    for u in usages_rango:
        for profesor_id in alumno_to_profesores.get(u.student_id, []):
            profesor_counter[profesor_id] += 1

    profesores = db.scalars(
        select(User).where(User.role == Role.PROFESOR)
    ).all()
    profesor_map = {p.id: p for p in profesores}

    profesores_top = []
    for profesor_id, count in profesor_counter.most_common(10):
        prof = profesor_map.get(profesor_id)
        if prof:
            profesores_top.append({
                "profesor": prof,
                "count": count,
            })

    # =========================
    # Alumnos nuevos del mes
    # =========================
    first_day_month = date(today.year, today.month, 1)
    alumnos_nuevos_mes = db.scalars(
        select(User)
        .where(
            User.role == Role.ALUMNO,
            User.is_active == True,
            User.created_at >= datetime.combine(first_day_month, datetime.min.time()),
        )
        .order_by(User.created_at.desc())
    ).all()

    # =========================
    # Seguimiento comercial
    # =========================
    seguimiento = {
        "total_contactar": len(cuotas_vencidas) + len(inactivos_bucket["6+"]) + len(inactivos_bucket["nunca"]),
        "morosos_alta": len([r for r in cuotas_vencidas if r["severity"] == "alta"]),
        "inactivos_criticos": len(inactivos_bucket["6+"]) + len(inactivos_bucket["nunca"]),
        "alumnos_nuevos_mes": len(alumnos_nuevos_mes),
        "activos_recientes": activos_recientes,
    }

    alertas = []
    if seguimiento["morosos_alta"] > 0:
        alertas.append({
            "title": "Morosidad alta",
            "text": f'{seguimiento["morosos_alta"]} alumnos con deuda prioritaria.',
            "level": "alta",
            "href": "/admin/home/morosos",
        })
    if seguimiento["inactivos_criticos"] > 0:
        alertas.append({
            "title": "Inactividad crítica",
            "text": f'{seguimiento["inactivos_criticos"]} alumnos sin venir hace 6+ meses o nunca.',
            "level": "alta",
            "href": "/admin/home/inactivos?bucket=6+",
        })
    if len(alumnos_nuevos_mes) > 0:
        alertas.append({
            "title": "Alumnos nuevos",
            "text": f'{len(alumnos_nuevos_mes)} alumnos nuevos este mes.',
            "level": "info",
            "href": "/admin/users",
        })

    return {
        "today": today,
        "period": current_period,
        "date_from": date_from,
        "date_to": date_to,
        "total_alumnos": total_alumnos,
        "presencias_hoy": presencias_hoy,
        "presencias_rango": presencias_rango,
        "activos_recientes": activos_recientes,
        "total_inactivos": total_inactivos,
        "inactivos_bucket": inactivos_bucket,
        "detalles_inactivos": detalles_inactivos,
        "cuotas_vencidas": cuotas_vencidas,
        "cuotas_vencidas_count": len(cuotas_vencidas),
        "cuotas_al_dia_count": len(cuotas_al_dia),
        "ultimas_presencias": ultimas_presencias,
        "presencias_por_dia": presencias_por_dia,
        "servicios": servicios,
        "horarios_top": horarios_top,
        "comparativo_mensual": comparativo_mensual,
        "profesores_top": profesores_top,
        "alumnos_nuevos_mes": alumnos_nuevos_mes,
        "seguimiento": seguimiento,
        "alertas": alertas,
    }


@router.get("/admin/home", response_class=HTMLResponse)
def admin_home(
    request: Request,
    date_from: str = Query(""),
    date_to: str = Query(""),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(["ADMINISTRADOR", "ADMINISTRATIVO"])),
):
    today = date.today()
    default_from = today.replace(day=1)
    default_to = today

    dt_from = parse_date_or_default(date_from, default_from)
    dt_to = parse_date_or_default(date_to, default_to)

    if dt_from > dt_to:
        dt_from, dt_to = dt_to, dt_from

    data = build_dashboard_data(db, dt_from, dt_to)
    return templates.TemplateResponse(
        "admin_home.html",
        {
            "request": request,
            "me": me,
            **data,
        },
    )


@router.get("/admin/home/inactivos", response_class=HTMLResponse)
def admin_home_inactivos(
    request: Request,
    bucket: str = Query(""),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(["ADMINISTRADOR", "ADMINISTRATIVO"])),
):
    today = date.today()
    data = build_dashboard_data(db, today.replace(day=1), today)
    rows = data["detalles_inactivos"]

    if bucket:
        rows = [r for r in rows if r["bucket"] == bucket]

    rows = sorted(
        rows,
        key=lambda r: (
            -999 if r["months"] is None else -r["months"],
            (r["alumno"].last_name or ""),
            (r["alumno"].first_name or ""),
            (r["alumno"].email or ""),
        )
    )

    return templates.TemplateResponse(
        "admin_inactivos.html",
        {
            "request": request,
            "me": me,
            "rows": rows,
            "bucket": bucket,
            "period": data["period"],
        },
    )


@router.get("/admin/home/morosos", response_class=HTMLResponse)
def admin_home_morosos(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(["ADMINISTRADOR", "ADMINISTRATIVO"])),
):
    today = date.today()
    data = build_dashboard_data(db, today.replace(day=1), today)

    return templates.TemplateResponse(
        "admin_morosos.html",
        {
            "request": request,
            "me": me,
            "rows": data["cuotas_vencidas"],
            "period": data["period"],
        },
    )


@router.get("/admin/home/inactivos/export")
def export_inactivos(
    bucket: str = Query(""),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(["ADMINISTRADOR", "ADMINISTRATIVO"])),
):
    today = date.today()
    data = build_dashboard_data(db, today.replace(day=1), today)
    rows = data["detalles_inactivos"]

    if bucket:
        rows = [r for r in rows if r["bucket"] == bucket]

    wb = Workbook()
    ws = wb.active
    ws.title = "Inactivos"
    ws.append(["Alumno", "Email", "DNI", "Última asistencia", "Meses sin venir", "Grupo"])

    for row in rows:
        a = row["alumno"]
        ws.append([
            a.full_name or a.email,
            a.email,
            a.dni or "",
            row["last_used_at"].strftime("%d/%m/%Y") if row["last_used_at"] else "Nunca",
            "" if row["months"] is None else row["months"],
            row["bucket"],
        ])

    return excel_response(wb, "inactivos.xlsx")


@router.get("/admin/home/morosos/export")
def export_morosos(
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(["ADMINISTRADOR", "ADMINISTRATIVO"])),
):
    today = date.today()
    data = build_dashboard_data(db, today.replace(day=1), today)
    rows = data["cuotas_vencidas"]

    wb = Workbook()
    ws = wb.active
    ws.title = "Morosos"
    ws.append(["Alumno", "Email", "DNI", "Membresía", "Período", "Motivo"])

    for row in rows:
        a = row["alumno"]
        ws.append([
            a.full_name or a.email,
            a.email,
            a.dni or "",
            row["membership_name"],
            row["periodo"],
            row["motivo"],
        ])

    return excel_response(wb, "morosos.xlsx")