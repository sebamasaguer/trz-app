from pathlib import Path
from datetime import datetime
import secrets
import string

from fastapi import APIRouter, Request, Depends, Form, Path as FPath
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import select

from ..db import get_db
from ..models import User, Role
from ..deps import require_roles
from ..security import hash_password

router = APIRouter()

BASE_DIR = Path(__file__).resolve().parents[1]  # .../app
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# ADMINISTRADOR y ADMINISTRATIVO pueden entrar al panel de usuarios
ALLOWED_ADMIN_PANEL = ["ADMINISTRADOR", "ADMINISTRATIVO"]


def _generate_temp_password(length: int = 12) -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


@router.get("/admin/users", response_class=HTMLResponse)
def admin_users_list(
    request: Request,
    q: str = "",
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED_ADMIN_PANEL)),
):
    stmt = select(User).order_by(User.id.desc())
    if q:
        like = f"%{q}%"
        stmt = stmt.where(
            (User.email.ilike(like))
            | (User.first_name.ilike(like))
            | (User.last_name.ilike(like))
            | (User.dni.ilike(like))
        )

    users = db.scalars(stmt).all()
    return templates.TemplateResponse(
        "users.html",
        {"request": request, "users": users, "q": q, "me": me},
    )


@router.get("/admin/users/new", response_class=HTMLResponse)
def admin_users_new_page(
    request: Request,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED_ADMIN_PANEL)),
):
    return templates.TemplateResponse(
        "user_form.html",
        {
            "request": request,
            "user": None,
            "roles": [r.value for r in Role],
            "me": me,
            "error": None,
            "mode": "new",
        },
    )


@router.post("/admin/users/new", response_class=HTMLResponse)
def admin_users_new_do(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    role: str = Form(...),
    first_name: str = Form(""),
    last_name: str = Form(""),
    dni: str = Form(""),
    birth_date: str = Form(""),
    address: str = Form(""),
    phone: str = Form(""),
    emergency_contact_name: str = Form(""),
    emergency_contact_phone: str = Form(""),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED_ADMIN_PANEL)),
):
    email = (email or "").strip().lower()
    dni = (dni or "").strip() or None

    exists = db.scalar(select(User).where(User.email == email))
    if exists:
        return templates.TemplateResponse(
            "user_form.html",
            {
                "request": request,
                "user": None,
                "roles": [r.value for r in Role],
                "me": me,
                "error": "Ese email ya existe",
                "mode": "new",
            },
            status_code=400,
        )

    if dni:
        exists_dni = db.scalar(select(User).where(User.dni == dni))
        if exists_dni:
            return templates.TemplateResponse(
                "user_form.html",
                {
                    "request": request,
                    "user": None,
                    "roles": [r.value for r in Role],
                    "me": me,
                    "error": "Ese DNI ya existe",
                    "mode": "new",
                },
                status_code=400,
            )

    bd = None
    if birth_date.strip():
        try:
            bd = datetime.strptime(birth_date.strip(), "%Y-%m-%d").date()
        except ValueError:
            return templates.TemplateResponse(
                "user_form.html",
                {
                    "request": request,
                    "user": None,
                    "roles": [r.value for r in Role],
                    "me": me,
                    "error": "Fecha inválida (YYYY-MM-DD)",
                    "mode": "new",
                },
                status_code=400,
            )

    u = User(
        email=email,
        password_hash=hash_password(password),
        role=Role(role),
        is_active=True,
        first_name=(first_name or "").strip(),
        last_name=(last_name or "").strip(),
        dni=dni,
        birth_date=bd,
        address=(address or "").strip(),
        phone=(phone or "").strip(),
        emergency_contact_name=(emergency_contact_name or "").strip(),
        emergency_contact_phone=(emergency_contact_phone or "").strip(),
        must_change_password=False,
    )
    db.add(u)
    db.commit()
    return RedirectResponse(url="/admin/users", status_code=302)


@router.get("/admin/users/{user_id}/edit", response_class=HTMLResponse)
def admin_users_edit_page(
    request: Request,
    user_id: int = FPath(...),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED_ADMIN_PANEL)),
):
    u = db.get(User, user_id)
    if not u:
        return RedirectResponse(url="/admin/users", status_code=302)

    return templates.TemplateResponse(
        "user_form.html",
        {
            "request": request,
            "user": u,
            "roles": [r.value for r in Role],
            "me": me,
            "error": None,
            "mode": "edit",
        },
    )


@router.post("/admin/users/{user_id}/edit", response_class=HTMLResponse)
def admin_users_edit_do(
    request: Request,
    user_id: int,
    email: str = Form(...),
    role: str = Form(...),
    first_name: str = Form(""),
    last_name: str = Form(""),
    dni: str = Form(""),
    birth_date: str = Form(""),
    address: str = Form(""),
    phone: str = Form(""),
    emergency_contact_name: str = Form(""),
    emergency_contact_phone: str = Form(""),
    is_active: str = Form("true"),
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED_ADMIN_PANEL)),
):
    u = db.get(User, user_id)
    if not u:
        return RedirectResponse(url="/admin/users", status_code=302)

    email = (email or "").strip().lower()
    dni = (dni or "").strip() or None

    exists = db.scalar(select(User).where(User.email == email, User.id != u.id))
    if exists:
        return templates.TemplateResponse(
            "user_form.html",
            {
                "request": request,
                "user": u,
                "roles": [r.value for r in Role],
                "me": me,
                "error": "Ese email ya existe",
                "mode": "edit",
            },
            status_code=400,
        )

    if dni:
        exists_dni = db.scalar(select(User).where(User.dni == dni, User.id != u.id))
        if exists_dni:
            return templates.TemplateResponse(
                "user_form.html",
                {
                    "request": request,
                    "user": u,
                    "roles": [r.value for r in Role],
                    "me": me,
                    "error": "Ese DNI ya existe",
                    "mode": "edit",
                },
                status_code=400,
            )

    bd = None
    if birth_date.strip():
        try:
            bd = datetime.strptime(birth_date.strip(), "%Y-%m-%d").date()
        except ValueError:
            return templates.TemplateResponse(
                "user_form.html",
                {
                    "request": request,
                    "user": u,
                    "roles": [r.value for r in Role],
                    "me": me,
                    "error": "Fecha inválida (YYYY-MM-DD)",
                    "mode": "edit",
                },
                status_code=400,
            )

    u.email = email
    u.role = Role(role)
    u.first_name = (first_name or "").strip()
    u.last_name = (last_name or "").strip()
    u.dni = dni
    u.birth_date = bd
    u.address = (address or "").strip()
    u.phone = (phone or "").strip()
    u.emergency_contact_name = (emergency_contact_name or "").strip()
    u.emergency_contact_phone = (emergency_contact_phone or "").strip()
    u.is_active = (is_active or "").lower() in ("true", "1", "on", "yes")

    db.commit()
    return RedirectResponse(url="/admin/users", status_code=302)


@router.post("/admin/users/{user_id}/disable")
def admin_users_disable(
    user_id: int,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED_ADMIN_PANEL)),
):
    u = db.get(User, user_id)
    if not u:
        return RedirectResponse(url="/admin/users", status_code=302)

    if u.id == me.id:
        return RedirectResponse(url="/admin/users", status_code=302)

    u.is_active = False
    db.commit()
    return RedirectResponse(url="/admin/users", status_code=302)


@router.get("/admin/users/{user_id}/reset-password", response_class=HTMLResponse)
def reset_password_page(
    request: Request,
    user_id: int,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED_ADMIN_PANEL)),
):
    u = db.get(User, user_id)
    if not u:
        return RedirectResponse(url="/admin/users", status_code=302)

    return templates.TemplateResponse(
        "reset_password.html",
        {"request": request, "user": u, "me": me, "temp_password": None},
    )


@router.post("/admin/users/{user_id}/reset-password", response_class=HTMLResponse)
def reset_password_do(
    request: Request,
    user_id: int,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED_ADMIN_PANEL)),
):
    u = db.get(User, user_id)
    if not u:
        return RedirectResponse(url="/admin/users", status_code=302)

    temp = _generate_temp_password(12)
    u.password_hash = hash_password(temp)
    u.is_active = True
    u.must_change_password = True
    db.commit()

    return templates.TemplateResponse(
        "reset_password.html",
        {"request": request, "user": u, "me": me, "temp_password": temp},
    )


@router.post("/admin/users/{user_id}/toggle")
def admin_users_toggle(
    user_id: int,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(ALLOWED_ADMIN_PANEL)),
):
    u = db.get(User, user_id)
    if not u:
        return RedirectResponse(url="/admin/users", status_code=302)

    if u.id == me.id:
        return RedirectResponse(url="/admin/users", status_code=302)

    u.is_active = not u.is_active
    db.commit()
    return RedirectResponse(url="/admin/users", status_code=302)


@router.post("/admin/users/{user_id}/delete")
def admin_users_delete(
    user_id: int,
    db: Session = Depends(get_db),
    me: User = Depends(require_roles(["ADMINISTRADOR"])),
):
    u = db.get(User, user_id)
    if not u:
        return RedirectResponse(url="/admin/users", status_code=302)

    if u.id == me.id:
        return RedirectResponse(url="/admin/users", status_code=302)

    u.is_active = False
    db.commit()
    return RedirectResponse(url="/admin/users", status_code=302)