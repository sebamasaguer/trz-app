import os, hmac, hashlib, secrets
import hashlib
from datetime import datetime, timedelta, date

from dotenv import load_dotenv
from jose import jwt, JWTError
from passlib.context import CryptContext

load_dotenv()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

JWT_SECRET = os.getenv("JWT_SECRET", "")
JWT_ACCESS_MIN = int(os.getenv("JWT_ACCESS_MIN", "60"))
ALGO = "HS256"

if len(JWT_SECRET) < 16:
    raise RuntimeError("JWT_SECRET demasiado corto. Usá una clave larga (mínimo 16).")

def _pepper_sha256(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def hash_password(password: str) -> str:
    return pwd_context.hash(_pepper_sha256(password))

def verify_password(password: str, password_hash: str) -> bool:
    return pwd_context.verify(_pepper_sha256(password), password_hash)

def create_access_token(payload: dict) -> str:
    exp = datetime.utcnow() + timedelta(minutes=JWT_ACCESS_MIN)
    to_encode = {**payload, "exp": exp}
    return jwt.encode(to_encode, JWT_SECRET, algorithm=ALGO)

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[ALGO])
    except JWTError:
        raise ValueError("Token inválido o expirado")
    
QR_SECRET = os.getenv("QR_SECRET", "cambiame_una_clave_larga_y_random")

def qr_make_payload(service: str, d: date | None = None) -> str:
    d = d or date.today()
    nonce = secrets.token_hex(6)
    base = f"{service}|{d.isoformat()}|{nonce}"
    sig = hmac.new(QR_SECRET.encode(), base.encode(), hashlib.sha256).hexdigest()[:16]
    # ✅ 5 partes: TRZ | service | date | nonce | sig
    return f"TRZ|{service}|{d.isoformat()}|{nonce}|{sig}"

def qr_verify_payload(payload: str) -> tuple[bool, str, date]:
    try:
        parts = payload.strip().split("|")
        # ✅ validar 5 partes
        if len(parts) != 5 or parts[0] != "TRZ":
            return (False, "", date.today())

        service = parts[1]
        d_str = parts[2]
        nonce = parts[3]
        sig = parts[4]
        d = date.fromisoformat(d_str)

        if service not in ("FUNCIONAL", "MUSCULACION"):
            return (False, "", d)

        base = f"{service}|{d.isoformat()}|{nonce}"
        expected = hmac.new(QR_SECRET.encode(), base.encode(), hashlib.sha256).hexdigest()[:16]

        if not hmac.compare_digest(sig, expected):
            return (False, "", d)

        return (True, service, d)
    except Exception:
        return (False, "", date.today())